#include "ArvoreBinaria.h"
#include <stdlib.h>
#include <stdio.h>

// Creates a new tree node containing the CPF and a pointer to the List Node
TreeNode *create_tree_node(long long cpf, ListNode *dataNode)
{
    TreeNode *node = (TreeNode *)malloc(sizeof(TreeNode));
    if (!node)
    {
        perror("Erro memoria TreeNode");
        exit(EXIT_FAILURE);
    }
    node->cpf = cpf;
    node->dataNode = dataNode;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// Inserts a node into the BST (Ordered Binary Tree)
TreeNode *insert_abo(TreeNode *root, long long cpf, ListNode *dataNode)
{
    if (root == NULL)
    {
        return create_tree_node(cpf, dataNode);
    }

    if (cpf < root->cpf)
    {
        root->left = insert_abo(root->left, cpf, dataNode);
    }
    else if (cpf > root->cpf)
    {
        root->right = insert_abo(root->right, cpf, dataNode);
    }
    // Duplicate CPFs are ignored

    return root;
}

int count_nodes(TreeNode *root)
{
    if (root == NULL)
        return 0;
    return 1 + count_nodes(root->left) + count_nodes(root->right);
}

int max_val(int a, int b) { return (a > b) ? a : b; }

// Calculates standard BST height (1-based for nodes)
int tree_height(TreeNode *root)
{
    if (root == NULL)
        return 0;
    return 1 + max_val(tree_height(root->left), tree_height(root->right));
}

TreeNode *get_min_node(TreeNode *root)
{
    if (root == NULL)
        return NULL;
    TreeNode *current = root;
    while (current->left != NULL)
    {
        current = current->left;
    }
    return current;
}

TreeNode *get_max_node(TreeNode *root)
{
    if (root == NULL)
        return NULL;
    TreeNode *current = root;
    while (current->right != NULL)
    {
        current = current->right;
    }
    return current;
}

void free_tree(TreeNode *root)
{
    if (root != NULL)
    {
        free_tree(root->left);
        free_tree(root->right);
        free(root);
        // Note: We do not free 'dataNode' here as it belongs to the Linked List
    }
}

// Writes tree content In-Order (CPF only) to file
void write_tree_in_order(TreeNode *root, FILE *f)
{
    if (root != NULL)
    {
        write_tree_in_order(root->left, f);

        if (root->dataNode)
        {
            fprintf(f, "%09lld\n", root->cpf);
        }

        write_tree_in_order(root->right, f);
    }
}
