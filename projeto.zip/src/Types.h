#ifndef TYPES_H
#define TYPES_H

typedef struct Citizen {
    long long cpf;
    int dv;
    int dia, mes, ano;
    char nome[51];
} Citizen;

#endif
