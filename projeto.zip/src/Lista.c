#include "Lista.h"
#include <stdlib.h>
#include <string.h>

ListNode *create_list_node(Citizen data)
{
    ListNode *newNode = (ListNode *)malloc(sizeof(ListNode));
    if (!newNode)
    {
        perror("Erro memoria ListNode");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

// Inserts a new node at the beginning of the list
ListNode *insert_list_head(ListNode *head, Citizen data)
{
    ListNode *newNode = create_list_node(data);
    if (head != NULL)
    {
        newNode->next = head;
        head->prev = newNode;
    }
    return newNode;
}

void free_list(ListNode *head)
{
    ListNode *current = head;
    while (current != NULL)
    {
        ListNode *temp = current;
        current = current->next;
        free(temp);
    }
}

// Writes list content to file
void print_list_to_file(ListNode *head, FILE *f)
{
    ListNode *current = head;
    while (current != NULL)
    {
        long long base = current->data.cpf;
        int dv = current->data.dv;

        fprintf(f, "%09lld-%02d %02d/%02d/%04d %s\n",
                base, dv,
                current->data.dia, current->data.mes, current->data.ano,
                current->data.nome);

        current = current->next;
    }
}
