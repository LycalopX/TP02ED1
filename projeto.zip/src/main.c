#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArvoreBinaria.h"
#include "Lista.h"
#include "Types.h"

// Função auxiliar para imprimir um nó no formato especificado
void print_node_data(TreeNode* node) {
    if (node && node->dataNode) {
        Citizen c = node->dataNode->data;
        printf("%09lld-%02d %02d/%02d/%04d %s\n", 
               c.cpf, c.dv, c.dia, c.mes, c.ano, c.nome);
    }
}

int main() {
    int option;
    if (scanf("%d", &option) != 1) {
        return 1;
    }

    FILE* f = fopen("basedados.txt", "r");
    if (!f) {
        printf("Erro ao abrir basedados.txt\n"); // Ajuste conforme necessidade
        return 1;
    }

    ListNode* listHead = NULL;
    TreeNode* treeRoot = NULL;

    char line_buffer[256]; // Buffer to hold one line from the file
    long long cpf_base;
    int cpf_dv;
    int dia, mes, ano;
    char nome[51];
    
    // Loop through the file, reading one line at a time
    while (fgets(line_buffer, sizeof(line_buffer), f) != NULL) {
        long long current_cpf_base_check; // Use a temporary variable for the check

        // First, try to parse just the first number to check for the termination condition (-1)
        if (sscanf(line_buffer, "%lld", &current_cpf_base_check) == 1 && current_cpf_base_check == -1) {
            break; // Found the termination marker
        }

        // Now, parse the full line. The %50s for nome will skip leading whitespace and read a single word.
        if (sscanf(line_buffer, "%lld %d %d %d %d %50s", &cpf_base, &cpf_dv, &dia, &mes, &ano, nome) == 6) {
            Citizen c;
            c.cpf = cpf_base;
            c.dv = cpf_dv;
            c.dia = dia;
            c.mes = mes;
            c.ano = ano;
            strcpy(c.nome, nome);

            listHead = insert_list_head(listHead, c);
            treeRoot = insert_abo(treeRoot, c.cpf, listHead);
        } else {
            fprintf(stderr, "Erro ao parsear linha do arquivo de dados: %s\n", line_buffer);
        }
    }
    fclose(f);

    // Gerar arquivos de saída (sempre, ou só na opção 2? PDF diz "O programa deve gravar...")
    // Parece que deve gravar sempre.
    FILE* out1 = fopen("dados1.txt", "w");
    if (out1) {
        print_list_to_file(listHead, out1);
        fclose(out1);
    }
    
    FILE* out2 = fopen("dados2.txt", "w");
    if (out2) {
        write_tree_in_order(treeRoot, out2);
        fclose(out2);
    }

    // Funcionalidade 2: Executar comandos extras
    if (option == 2) {
        system("cat dados1.txt");
        system("cat dados2.txt");
    }

    // Saída na tela (Stats)
    printf("%d\n", count_nodes(treeRoot));
    printf("%d\n", tree_height(treeRoot));
    
    // Dados do 1o nodo considerando ordenação (Menor CPF)
    TreeNode* minNode = get_min_node(treeRoot);
    print_node_data(minNode);
    
    // Dados do ultimo nodo considerando ordenação (Maior CPF)
    TreeNode* maxNode = get_max_node(treeRoot);
    print_node_data(maxNode);

    // Limpeza
    free_tree(treeRoot); // Libera nós da árvore
    free_list(listHead); // Libera nós da lista

    return 0;
}