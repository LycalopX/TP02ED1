#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArvoreBinaria.h"
#include "Lista.h"
#include "Types.h"

// Função auxiliar para imprimir um nó no formato especificado
void print_node_data(TreeNode* node) {
    if (node && node->dataNode) {
        Citizen c = node->dataNode->data;
        printf("%09lld-%02d %02d/%02d/%04d %s\n", 
               c.cpf, c.dv, c.dia, c.mes, c.ano, c.nome);
    }
}

// Helper para remover newline e carriage return
void trim_string(char* str) {
    size_t len = strlen(str);
    while(len > 0 && (str[len-1] == '\n' || str[len-1] == '\r')) {
        str[len-1] = '\0';
        len--;
    }
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);

    int option;
    char buffer[512]; // Buffer generoso

    // Ler opcao
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) return 1;
    if (sscanf(buffer, "%d", &option) != 1) return 1;

    FILE* f = fopen("basedados.txt", "r");
    if (!f) {
        // Tenta abrir .csv se .txt falhar, apenas por garantia local
        f = fopen("basedados.csv", "r");
        if (!f) {
            printf("Erro ao abrir basedados.txt ou basedados.csv\n"); 
            return 1;
        }
    }

    ListNode* listHead = NULL;
    TreeNode* treeRoot = NULL;

    // Detectar formato lendo a primeira linha
    long pos_inicial = ftell(f);
    if (fgets(buffer, sizeof(buffer), f) == NULL) {
        fclose(f);
        return 0; // Arquivo vazio
    }
    
    int is_csv = (strchr(buffer, ',') != NULL);
    
    // Volta para o inicio para processar corretamente
    fseek(f, pos_inicial, SEEK_SET);

    while (1) {
        Citizen c;
        long long cpf_base;

        if (is_csv) {
            // --- FORMATO CSV ---
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            trim_string(buffer);
            if (strlen(buffer) == 0) continue;

            // Verifica terminador
            // O terminador pode ser "-1 , $FIM$" ou apenas "-1"
            if (strncmp(buffer, "-1", 2) == 0) break;
            
            // Parse: CPF,DV,Dia,Mes,Ano,Nome
            // Nome pode ter espaços, %[^,\n] lê até virgula ou fim de linha
            char nome_temp[100];
            int fields = sscanf(buffer, "%lld,%d,%d,%d,%d,%[^,\n]", 
                   &cpf_base, &c.dv, &c.dia, &c.mes, &c.ano, nome_temp);
            
            if (fields < 6) continue; // Linha invalida

            c.cpf = cpf_base;
            strncpy(c.nome, nome_temp, 50);
            c.nome[50] = '\0';

        } else {
            // --- FORMATO TXT (Multi-linhas) ---
            
            // 1. Ler CPF
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            trim_string(buffer);
            if (strlen(buffer) == 0) continue;

            if (sscanf(buffer, "%lld", &cpf_base) != 1) break;
            if (cpf_base == -1) break; // Fim

            c.cpf = cpf_base;

            // 2. Ler DV
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            c.dv = atoi(buffer);

            // 3. Ler Dia
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            c.dia = atoi(buffer);

            // 4. Ler Mes
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            c.mes = atoi(buffer);

            // 5. Ler Ano
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            c.ano = atoi(buffer);

            // 6. Ler Nome
            if (fgets(buffer, sizeof(buffer), f) == NULL) break;
            trim_string(buffer);
            strncpy(c.nome, buffer, 50);
            c.nome[50] = '\0';
        }

        // Inserir nas estruturas
        listHead = insert_list_head(listHead, c);
        treeRoot = insert_abo(treeRoot, c.cpf, listHead);
    }
    fclose(f);

    // Gerar arquivos de saída
    FILE* out1 = fopen("dados1.txt", "w");
    if (out1) {
        print_list_to_file(listHead, out1);
        fclose(out1);
    }
    
    FILE* out2 = fopen("dados2.txt", "w");
    if (out2) {
        write_tree_in_order(treeRoot, out2);
        fclose(out2);
    }

    // Funcionalidade 2: Executar comandos extras
    if (option == 2) {
        system("cat dados1.txt");
        system("cat dados2.txt");
    }

    // Saída na tela (Stats)
    printf("%d\n", count_nodes(treeRoot));
    printf("%d\n", tree_height(treeRoot));
    
    // Dados do 1o nodo (Menor CPF)
    TreeNode* minNode = get_min_node(treeRoot);
    print_node_data(minNode);
    
    // Dados do ultimo nodo (Maior CPF)
    TreeNode* maxNode = get_max_node(treeRoot);
    print_node_data(maxNode);

    // Limpeza
    free_tree(treeRoot); 
    free_list(listHead); 

    return 0;
}
