#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LDED.h" //inclui os Prot�tipos

Lista* cria_lista()
{
    Lista* li = (Lista*) malloc(sizeof(Lista));
    if (li != NULL)
        *li = NULL;
    return li;
}

void libera_lista(Lista* li)
{
    if (li != NULL)
	{
        Elem_ld* no;
        while ((*li) != NULL)
		{
            no = *li;
            *li = (*li)->prox;
            free(no);
        }
        free(li);
    }
}

int consulta_lista_pos(Lista* li, int pos, Tipo_Dado_LD *dt)
{
    if (li == NULL || pos <= 0)
        return ERRO;
    Elem_ld *no = *li;
    int i = 1;
    while (no != NULL && i < pos)
	{
        no = no->prox;
        i++;
    }
    if (no == NULL)
        return ERRO;
    else
	{
        *dt = no->dado;
        return OK;
    }
}

int consulta_lista_dado(Lista* li, Tipo_Dado_LD dt, Elem_ld **el)
{
    if (li == NULL)
        return 0;
    Elem_ld *no = *li;
    while (no != NULL && strcmp(no->dado.cpf, dt.cpf)){
        no = no->prox;
    }
    if (no == NULL)
        return ERRO;
    else
	{
        *el = no;
        return OK;
    }
}

int insere_lista_final(Lista* li, Tipo_Dado_LD dt)
{
    Elem_ld *no;

    if (li == NULL) return ERRO;
    no = (Elem_ld*) malloc(sizeof(Elem_ld));
    if (no == NULL)  return ERRO;

    no->dado = dt;
    no->prox = NULL;

	if ((*li) == NULL)
	{   //lista vazia: insere in�cio
        no->ant = NULL;
        *li = no;
    }else
	{
        Elem_ld *aux;
        aux = *li;
        while (aux->prox != NULL){
            aux = aux->prox;
        }
        aux->prox = no;
        no->ant = aux;
    }
    return OK;
}

int insere_lista_inicio(Lista* li, Tipo_Dado_LD dt)
{
    if (li == NULL)
        return ERRO;
    Elem_ld* no;
    no = (Elem_ld*) malloc(sizeof(Elem_ld));
    if (no == NULL)
        return ERRO;

    no->dado = dt;
    no->prox = (*li);
    no->ant = NULL;

	if (*li != NULL)
        (*li)->ant = no;
    *li = no;
    return OK;
}

Elem_ld* insere_lista_inicio_retorna_ptr(Lista* li, Tipo_Dado_LD dt)
{
    if (li == NULL)
        return NULL;
    Elem_ld* no;
    no = (Elem_ld*) malloc(sizeof(Elem_ld));
    if (no == NULL)
        return NULL;

    no->dado = dt;
    no->prox = (*li);
    no->ant = NULL;

	if (*li != NULL)
        (*li)->ant = no;
    *li = no;
    return no;
}

int insere_lista_ordenada(Lista* li, Tipo_Dado_LD dt)
{
    if (li == NULL)
        return ERRO;
    Elem_ld *no = (Elem_ld*) malloc(sizeof(Elem_ld));
    if (no == NULL)
        return ERRO;
    no->dado = dt;
    if ((*li) == NULL)
	{  //lista vazia: insere in�cio
        no->prox = NULL;
        no->ant = NULL;
        *li = no;
        return OK;
    }
    else{
        Elem_ld *ante, *atual = *li;
        while (atual != NULL && atoi(atual->dado.cpf) < atoi(dt.cpf))
		{
            ante = atual;
            atual = atual->prox;
        }
        if (atual == *li)
		{   //insere in�cio
            no->ant = NULL;
            (*li)->ant = no;
            no->prox = (*li);
            *li = no;
        } else
		{
            no->prox = ante->prox;
            no->ant = ante;
            ante->prox = no;
            if (atual != NULL)
                atual->ant = no;
        }
        return OK;
    }
}

int remove_lista(Lista* li, Tipo_Dado_LD dt)
{   //TERMINAR
    if (li == NULL)
        return ERRO;
    if ((*li) == NULL)//lista vazia
        return ERRO;
    Elem_ld *no = *li;
    while (no != NULL && strcmp(no->dado.cpf, dt.cpf)){
        no = no->prox;
    }
    if (no == NULL)//n�o encontrado
        return ERRO;

    if (no->ant == NULL)//remover o primeiro?
        *li = no->prox;
    else
        no->ant->prox = no->prox;

    if (no->prox != NULL)//n�o � o �ltimo?
        no->prox->ant = no->ant;

    free(no);
    return OK;
}


int remove_lista_inicio(Lista* li)
{
    if (li == NULL)
        return ERRO;
    if ((*li) == NULL)//lista vazia
        return ERRO;

    Elem_ld *no = *li;
    *li = no->prox;
    if (no->prox != NULL)
        no->prox->ant = NULL;

    free(no);
    return OK;
}

int remove_lista_final(Lista* li)
{
    if (li == NULL)
        return ERRO;
    if ((*li) == NULL) //lista vazia
        return ERRO;

    Elem_ld *no = *li;
    while (no->prox != NULL)
        no = no->prox;

    if (no->ant == NULL) //remover o primeiro e �nico
        *li = no->prox;
    else
        no->ant->prox = NULL;

    free(no);
    return OK;
}

int tamanho_lista(Lista* li)
{
    if (li == NULL)
        return 0;
    int cont = 0;
    Elem_ld* no = *li;
    while (no != NULL){
        cont++;
        no = no->prox;
    }
    return cont;
}

int lista_cheia(Lista* li)
{
    return FALSO;
}

int lista_vazia(Lista* li)
{
    if (li == NULL)
        return OK;
    if (*li == NULL)
        return OK;
    return FALSO;
}

void exibe_lista(Lista* li)
{
    Elem_ld* no = *li;

    if (li == NULL)
        return;
    while (no != NULL)
    {
        printf("CPF: %s - Nome: %s # ", no->dado.cpf, no->dado.nome);
        no = no->prox;
    }
    printf("\n");
}

void imprime_lista(Lista* li)
{
    Elem_ld* no = *li;

    if (li == NULL)
        return;
    while (no != NULL)
    {
        printf("CPF: %s-%s | Nome: %s | Data: %d/%d/%d\n", no->dado.cpf, no->dado.dv, no->dado.nome, no->dado.dia, no->dado.mes, no->dado.ano);
        no = no->prox;
    }
}

void grava_arquivo_LDE(Lista *li, char *nome_arquivo) {
    FILE *arq = fopen(nome_arquivo, "wt");
    if (arq == NULL) {
        printf("Erro: Nao foi possivel criar o arquivo %s\n", nome_arquivo);
        return;
    }

    Elem_ld *no = *li;
    while (no != NULL) {
        fprintf(arq, "%s-%s %02d/%02d/%04d %s\n",
                no->dado.cpf,
                no->dado.dv,
                no->dado.dia, no->dado.mes, no->dado.ano,
                no->dado.nome);

        no = no->prox;
    }

    fclose(arq);
}
