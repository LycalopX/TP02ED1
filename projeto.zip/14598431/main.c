//NOME: MATHEUS MARCHI BARON
//NUSP: 14598431

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LDED.h"
#include "ArvoreBinaria.h"

void executar(Lista *lista, ArvBin *arvore, char *nome_arquivo);

void executar(Lista *lista, ArvBin *arvore, char *nome_arquivo){

    FILE *arqIn;

    char linha[200];
    char *sp;

    int i = 0;

    arqIn = fopen(nome_arquivo, "rt");
    if(arqIn == NULL){
        printf("Erro ao abrir o arquivo %s.\n", nome_arquivo);
        exit(0);
    }

    Tipo_Dado_LD pessoa;
    Elem_ld *enderecoElemento;

    Tipo_Dado_ABO indice;

    while(fgets(linha, 200, arqIn) != NULL){

        sp = strtok(linha, ",");
        for(i = 0; i < strlen(sp); i++){
            if(sp[i] <= 32) sp[i] = '\0';
        }

        if(strcmp(sp, "-1") == 0) break;

        //cpf
        strcpy(pessoa.cpf, sp);

        //dv
        sp = strtok(NULL, ",");
        strcpy(pessoa.dv, sp);

        //dia
        sp = strtok(NULL, ",");
        pessoa.dia = atoi(sp);

        //mes
        sp = strtok(NULL, ",");
        pessoa.mes = atoi(sp);

        //ano
        sp = strtok(NULL, ",");
        pessoa.ano = atoi(sp);

        //nome
        sp = strtok(NULL, ",");
        strcpy(pessoa.nome, sp);

        //insere na lista o que foi lido na linha do arquivo e retorna para enderecoElemento o
        //endere�o do elemento adicionado na lista
        enderecoElemento = insere_lista_inicio_retorna_ptr(lista, pessoa);
        if(enderecoElemento == NULL){
            printf("Erro: falha ao alocar na lista\n");
            exit(0);
        }

        //o elemento da �rvore recebe o cpf e o endere�o do elemento correspondente da lista
        //e insere na arvore
        strcpy(indice.cpf, pessoa.cpf);
        indice.link = enderecoElemento;
        insere_ArvBin(arvore, indice);


    }

    printf("%d\n%d\n", totalNO_ArvBin(arvore), altura_ArvBin(arvore));

    Elem_ld *menor = Obter_Menor_ABO(arvore);
    if(menor != NULL) printf("%s-%s %02d/%02d/%04d %s\n", menor->dado.cpf, menor->dado.dv, menor->dado.dia, menor->dado.mes, menor->dado.ano, menor->dado.nome);

    Elem_ld *maior = Obter_Maior_ABO(arvore);
    if(maior != NULL) printf("%s-%s %02d/%02d/%04d %s\n", maior->dado.cpf, maior->dado.dv, maior->dado.dia, maior->dado.mes, maior->dado.ano, maior->dado.nome);

    //Do jeito que foram implementadas, ambas as fun��es criam e fecham os arquivos.
    //Basta passar o nomo do arquivo a ser criado
    grava_arquivo_LDE(lista, "dados1.txt");
    grava_arquivo_ABO(arvore, "dados2.txt");

    fclose(arqIn);

}

int main() {

    int i = 0;
    int modoFuncionamento;

    Lista *lista = cria_lista();
    ArvBin *arvore = cria_ArvBin();

    scanf("%d", &modoFuncionamento);

    switch(modoFuncionamento){

        case 1:
            executar(lista, arvore, "basedados.csv");
            break;

        case 2:
            executar(lista, arvore, "basedados.csv");
            system("cat dados1.txt");
            system("cat dados2.txt");
            break;

        default:
            break;
    }

    libera_lista(lista);
    libera_ArvBin(arvore);

    return 0;
}
