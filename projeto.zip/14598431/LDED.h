//Arquivo LDED.h - Lista Dinamica Encadeada Dupla

#ifndef LDED_H
#define LDED_H

#ifndef FALSO
#define FALSO      0
#define VERDADEIRO 1
#endif

#ifndef OK
#define OK         1
#define ERRO       0
#endif

typedef struct{

    char cpf[10], dv[3];
    int dia, mes, ano;
    char nome[51];

}Tipo_Dado_LD;

//Defini��o do tipo lista
struct elemento_ld{
    struct elemento_ld *ant;
    Tipo_Dado_LD dado;
    struct elemento_ld *prox;
};

typedef struct elemento_ld Elem_ld;

typedef struct elemento_ld* Lista;

Lista* cria_lista();
void libera_lista(Lista* li);
int consulta_lista_pos(Lista* li, int pos, Tipo_Dado_LD *dt);
int consulta_lista_dado(Lista* li, Tipo_Dado_LD dt, Elem_ld **el);
int insere_lista_final(Lista* li, Tipo_Dado_LD dt);
int insere_lista_inicio(Lista* li, Tipo_Dado_LD dt);
Elem_ld* insere_lista_inicio_retorna_ptr(Lista* li, Tipo_Dado_LD dt);
int insere_lista_ordenada(Lista* li, Tipo_Dado_LD dt);
int remove_lista(Lista* li, Tipo_Dado_LD dt);
int remove_lista_inicio(Lista* li);
int remove_lista_final(Lista* li);
int tamanho_lista(Lista* li);
int lista_vazia(Lista* li);
int lista_cheia(Lista* li);
void exibe_lista(Lista* li);
void imprime_lista(Lista* li);
void grava_arquivo_LDE(Lista *li, char *nome_arquivo);

#endif
