#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArvoreBinaria.h" //inclui os Prot�tipos

// Local functions (Prototipo da funcao)
void libera_NO(struct NO* no);
struct NO* remove_atual(struct NO* atual);
void aux_grava_EmOrdem(ArvBin *raiz, FILE *arq);

// TAD ABO - Arvore Binaria Ordenada

ArvBin* cria_ArvBin(){
    ArvBin* raiz = (ArvBin*) malloc(sizeof(ArvBin));
    if(raiz != NULL)
        *raiz = NULL;
    return raiz;
}

void libera_NO(struct NO* no){
    if(no == NULL)
        return;
    libera_NO(no->esq);
    libera_NO(no->dir);
    free(no);
    no = NULL;
}

void libera_ArvBin(ArvBin* raiz){
    if(raiz == NULL)
        return;
    libera_NO(*raiz);//libera cada n�
    free(raiz);//libera a raiz
}

int insere_ArvBin(ArvBin* raiz, Tipo_Dado_ABO valor){

    if (*raiz == NULL) {
        struct NO* novo = (struct NO*) malloc(sizeof(struct NO));
        if (novo == NULL) return 0; // Falha de mem�ria

        novo->info = valor;
        novo->esq = NULL;
        novo->dir = NULL;

        *raiz = novo;
        return 1;
    }

    int comparacao = strcmp(valor.cpf, (*raiz)->info.cpf);

    if (comparacao == 0) {
        return 0;
    }

    if (comparacao < 0) {
        return insere_ArvBin(&((*raiz)->esq), valor);
    } else {
        return insere_ArvBin(&((*raiz)->dir), valor);
    }
}

struct NO* remove_atual(struct NO* atual) {
    struct NO *no1, *no2;
    if(atual->esq == NULL){
        no2 = atual->dir;
        free(atual);
        return no2;
    }
    no1 = atual;
    no2 = atual->esq;
    while(no2->dir != NULL){
        no1 = no2;
        no2 = no2->dir;
    }
    // no2 � o n� anterior a r na ordem e-r-d
    // no1 � o pai de no2
    if(no1 != atual){
        no1->dir = no2->esq;
        no2->esq = atual->esq;
    }
    no2->dir = atual->dir;
    free(atual);
    return no2;
}

int estaVazia_ArvBin(ArvBin *raiz){
    if(raiz == NULL)
        return 1;
    if(*raiz == NULL)
        return 1;
    return 0;
}

int totalNO_ArvBin(ArvBin *raiz){
    if (raiz == NULL)
        return 0;
    if (*raiz == NULL)
        return 0;
    int alt_esq = totalNO_ArvBin(&((*raiz)->esq));
    int alt_dir = totalNO_ArvBin(&((*raiz)->dir));
    return(alt_esq + alt_dir + 1);
}

int altura_ArvBin(ArvBin *raiz){
    if (raiz == NULL)
        return 0;
    if (*raiz == NULL)
        return 0;
    int alt_esq = altura_ArvBin(&((*raiz)->esq));
    int alt_dir = altura_ArvBin(&((*raiz)->dir));
    if (alt_esq > alt_dir)
        return (alt_esq + 1);
    else
        return(alt_dir + 1);
}


void preOrdem_ArvBin(ArvBin *raiz)
{
    if(raiz == NULL)
        return;
    if(*raiz != NULL){
        printf("CPF: %s -> Link para: %s\n", (*raiz)->info.cpf, (*raiz)->info.link->dado.nome);
        preOrdem_ArvBin(&((*raiz)->esq));
        preOrdem_ArvBin(&((*raiz)->dir));
    }
}

void emOrdem_ArvBin(ArvBin *raiz)
{
    if(raiz == NULL)
        return;

    if(*raiz != NULL){
        emOrdem_ArvBin(&((*raiz)->esq));
        printf("CPF: %s", (*raiz)->info.cpf);
        printf("\n");
        emOrdem_ArvBin(&((*raiz)->dir));
    }
}

void posOrdem_ArvBin(ArvBin *raiz)
{
    if(raiz == NULL)
        return;
    if(*raiz != NULL){
        posOrdem_ArvBin(&((*raiz)->esq));
        posOrdem_ArvBin(&((*raiz)->dir));
        printf("CPF: %s -> Link para: %s\n", (*raiz)->info.cpf, (*raiz)->info.link->dado.nome);
    }
}

// Funcoes Adicionais de Arvore

void Exibe_emOrdem_ArvBin(ArvBin *raiz)
{
    if(raiz == NULL)
        return;

    if(*raiz != NULL)
    {
        printf("Atual: %s - Vai para Esquerda \n",(*raiz)->info.cpf);
        Exibe_emOrdem_ArvBin(&((*raiz)->esq));
        printf("Dado : %s \n",(*raiz)->info.cpf);
        printf("Atual: %s - Vai para Direita \n",(*raiz)->info.cpf);
        Exibe_emOrdem_ArvBin(&((*raiz)->dir));
        printf("Feito(%s) \n",(*raiz)->info.cpf);
    }
    else
        printf("NULL\n");

}

Elem_ld* Obter_Menor_ABO(ArvBin *raiz) {
    if (raiz == NULL || *raiz == NULL) return NULL;

    struct NO *atual = *raiz;
    while (atual->esq != NULL) {
        atual = atual->esq;
    }
    return atual->info.link;
}

Elem_ld* Obter_Maior_ABO(ArvBin *raiz) {
    if (raiz == NULL || *raiz == NULL) return NULL;

    struct NO *atual = *raiz;
    while (atual->dir != NULL) {
        atual = atual->dir;
    }
    return atual->info.link;
}

void grava_arquivo_ABO(ArvBin *raiz, char *nome_arquivo) {
    FILE *arq = fopen(nome_arquivo, "wt");
    if (arq == NULL) {
        printf("Erro: Nao foi possivel criar %s\n", nome_arquivo);
        return;
    }
    aux_grava_EmOrdem(raiz, arq);

    fclose(arq);
}

//AUXILIAR
void aux_grava_EmOrdem(ArvBin *raiz, FILE *arq) {
    if (raiz == NULL || *raiz == NULL) return;

    aux_grava_EmOrdem(&((*raiz)->esq), arq);

    fprintf(arq, "%s\n", (*raiz)->info.cpf);

    aux_grava_EmOrdem(&((*raiz)->dir), arq);
}
