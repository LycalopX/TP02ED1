//  Arquivo ArvBinaria.h
//  TAD: ProjArvoreBinaria-V2

#include "LDED.h"

#ifndef FALSO
#define FALSO      0
#define VERDADEIRO 1
#endif

#ifndef OK
#define OK         1
#define ERRO       0
#endif

typedef struct{
    char cpf[10];
    Elem_ld *link;

}Tipo_Dado_ABO;

//Defini��o do tipo Arvore
struct NO{
    Tipo_Dado_ABO info;
    struct NO *esq;
    struct NO *dir;
};

typedef struct NO NodoArvBin;
typedef struct NO *ArvBin;

ArvBin* cria_ArvBin();
void libera_ArvBin(ArvBin *raiz);
int insere_ArvBin(ArvBin* raiz, Tipo_Dado_ABO valor);
int estaVazia_ArvBin(ArvBin *raiz);
int altura_ArvBin(ArvBin *raiz);
int totalNO_ArvBin(ArvBin *raiz);
void preOrdem_ArvBin(ArvBin *raiz);
void emOrdem_ArvBin(ArvBin *raiz);
void posOrdem_ArvBin(ArvBin *raiz);

// Funcoes Adicionais
void Exibe_emOrdem_ArvBin(ArvBin *raiz);
Elem_ld* Obter_Menor_ABO(ArvBin *raiz);
Elem_ld* Obter_Maior_ABO(ArvBin *raiz);
void grava_arquivo_ABO(ArvBin *raiz, char *nome_arquivo);

